﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyRTSGame
{
    class MeleeUnit 
    {
        #region Constructors
        public MeleeUnit()
        {

        }
        #endregion

    }
}
