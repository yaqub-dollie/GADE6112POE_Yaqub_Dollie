﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameEngine : MonoBehaviour
{
    public int height;
    public int width;


    void Start()
    {
        int xStart = 48;
        int yStart = 24;
        var tileSize = new Vector2(2, 2);

        for (int k = 0; k < height; k++)
        {
            var yPos = -k * tileSize.y + yStart;
            for (int i = 0; i < width; i++)
            {
                var xPos = i * tileSize.x - xStart;
                Instantiate(Resources.Load("GrassTile"), new Vector3(xPos, yPos, 0), Quaternion.identity);
            }
        }/*
        map.populate();
        Debug.Log("Number of units: " + map.NumberOfUnitsOnMap.ToString());
        foreach (Unit temp in map.UnitsOnMap)*/
        {/*
            if (temp != null)
            {
                var unitType = temp.GetType().ToString();
                var xPos = temp.X * tileSize.x - xStart;
                var yPos = -temp.Y * tileSize.y + yStart;
                if (unitType.Contains("MeleeUnit"))
                {
                    if (temp.Faction.Equals("RED"))
                        Instantiate(Resources.Load("MeleeUnitR"), new Vector3(xPos, yPos, -2), Quaternion.identity);
                    else
                        Instantiate(Resources.Load("MeleeUnitB"), new Vector3(xPos, yPos, -2), Quaternion.identity);
                }
                else
                {
                    if (temp.Faction.Equals("RED"))
                        Instantiate(Resources.Load("RangedUnitR"), new Vector3(xPos, yPos, -2), Quaternion.identity);
                    else
                        Instantiate(Resources.Load("RangedUnitB"), new Vector3(xPos, yPos, -2), Quaternion.identity);
                }
            }
        */}
    }

}

