﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyRTSGame
{
   /* class RangedUnit : Units
    {
        public RangedUnit(int x, int y, int health, int speed, int attack, int attackRange, int faction, int symbol);
        : base(x, y, health, speed, attack, attackRange, faction, symbol)

           this.x = x;
           this.y =y;
           this.health = health; 
           this.sped = speed;
           this.attack = attack;
           this.attackRange = attackRange;
           this.faction = faction;
           this.symbol = symbol;


    }*/
}
