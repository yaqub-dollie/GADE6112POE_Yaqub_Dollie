﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyRTSGame
{
    abstract class Units
    {
        protected int x;
        protected int y;
        protected int health;
        protected int speed;
        protected bool attack;
        protected int attackRange;
        protected string Faction;
        protected string symbol;

        #region
        public Units()
            {/*
            x = 0;
            y = 0;
            health = 10;
            speed = -1;
            attack = 3;
            attackRange = 0;
            Faction = 0;
            symbol = 0;
            */}

        public Units(int x, int y, int health, int speed, int attack, int attackRange, string faction, string symbol)
        {
            /*
            this.x = x;
            this.y = y;
            this.health = health;
            this.speed = speed;
            this.attack = attack;
            this.attackRange = attackRange;
            */
        }
        #endregion

        abstract public void move(int position1, int position2, int position3, int position4);// a method to handle the movement of units
        abstract public bool combat();// a method to hnadle the combat between units
        abstract public bool isEnemyUnitInRange(int enemyPosition1, int enemyPosition2, int enemyPosition3, int enemyPosition4);// a method to determine if another unit is in attacking range
        abstract public int returnUnitPosition(Units u);// A method to return position of the closest other unit to this unit
        abstract public bool isUnitAlive();//A method to handle the death/ destruction of this unit
        abstract public void toString();// a tostring method to return a neatly formatted string displaying all of the units information

    }
}
